gdjs.Main_32SceneCode = {};
gdjs.Main_32SceneCode.forEachCount0_2 = 0;

gdjs.Main_32SceneCode.forEachCount1_2 = 0;

gdjs.Main_32SceneCode.forEachCount2_2 = 0;

gdjs.Main_32SceneCode.forEachIndex2 = 0;

gdjs.Main_32SceneCode.forEachObjects2 = [];

gdjs.Main_32SceneCode.forEachTemporary2 = null;

gdjs.Main_32SceneCode.forEachTotalCount2 = 0;

gdjs.Main_32SceneCode.GDWizardObjects1= [];
gdjs.Main_32SceneCode.GDWizardObjects2= [];
gdjs.Main_32SceneCode.GDWizardObjects3= [];
gdjs.Main_32SceneCode.GDWizardObjects4= [];
gdjs.Main_32SceneCode.GDBlueFloorObjects1= [];
gdjs.Main_32SceneCode.GDBlueFloorObjects2= [];
gdjs.Main_32SceneCode.GDBlueFloorObjects3= [];
gdjs.Main_32SceneCode.GDBlueFloorObjects4= [];
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects1= [];
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects2= [];
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects3= [];
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects4= [];
gdjs.Main_32SceneCode.GDHealthObjects1= [];
gdjs.Main_32SceneCode.GDHealthObjects2= [];
gdjs.Main_32SceneCode.GDHealthObjects3= [];
gdjs.Main_32SceneCode.GDHealthObjects4= [];
gdjs.Main_32SceneCode.GDManaObjects1= [];
gdjs.Main_32SceneCode.GDManaObjects2= [];
gdjs.Main_32SceneCode.GDManaObjects3= [];
gdjs.Main_32SceneCode.GDManaObjects4= [];
gdjs.Main_32SceneCode.GDScoreObjects1= [];
gdjs.Main_32SceneCode.GDScoreObjects2= [];
gdjs.Main_32SceneCode.GDScoreObjects3= [];
gdjs.Main_32SceneCode.GDScoreObjects4= [];
gdjs.Main_32SceneCode.GDYellowCrystalObjects1= [];
gdjs.Main_32SceneCode.GDYellowCrystalObjects2= [];
gdjs.Main_32SceneCode.GDYellowCrystalObjects3= [];
gdjs.Main_32SceneCode.GDYellowCrystalObjects4= [];
gdjs.Main_32SceneCode.GDSkeletonPirateObjects1= [];
gdjs.Main_32SceneCode.GDSkeletonPirateObjects2= [];
gdjs.Main_32SceneCode.GDSkeletonPirateObjects3= [];
gdjs.Main_32SceneCode.GDSkeletonPirateObjects4= [];
gdjs.Main_32SceneCode.GDRedPlatformObjects1= [];
gdjs.Main_32SceneCode.GDRedPlatformObjects2= [];
gdjs.Main_32SceneCode.GDRedPlatformObjects3= [];
gdjs.Main_32SceneCode.GDRedPlatformObjects4= [];
gdjs.Main_32SceneCode.GDBrownBlockObjects1= [];
gdjs.Main_32SceneCode.GDBrownBlockObjects2= [];
gdjs.Main_32SceneCode.GDBrownBlockObjects3= [];
gdjs.Main_32SceneCode.GDBrownBlockObjects4= [];
gdjs.Main_32SceneCode.GDIceSpellObjects1= [];
gdjs.Main_32SceneCode.GDIceSpellObjects2= [];
gdjs.Main_32SceneCode.GDIceSpellObjects3= [];
gdjs.Main_32SceneCode.GDIceSpellObjects4= [];
gdjs.Main_32SceneCode.GDIceBlastObjects1= [];
gdjs.Main_32SceneCode.GDIceBlastObjects2= [];
gdjs.Main_32SceneCode.GDIceBlastObjects3= [];
gdjs.Main_32SceneCode.GDIceBlastObjects4= [];
gdjs.Main_32SceneCode.GDLargeGuardObjects1= [];
gdjs.Main_32SceneCode.GDLargeGuardObjects2= [];
gdjs.Main_32SceneCode.GDLargeGuardObjects3= [];
gdjs.Main_32SceneCode.GDLargeGuardObjects4= [];
gdjs.Main_32SceneCode.GDGuardObjects1= [];
gdjs.Main_32SceneCode.GDGuardObjects2= [];
gdjs.Main_32SceneCode.GDGuardObjects3= [];
gdjs.Main_32SceneCode.GDGuardObjects4= [];
gdjs.Main_32SceneCode.GDWinTextObjects1= [];
gdjs.Main_32SceneCode.GDWinTextObjects2= [];
gdjs.Main_32SceneCode.GDWinTextObjects3= [];
gdjs.Main_32SceneCode.GDWinTextObjects4= [];
gdjs.Main_32SceneCode.GDGameOverTextObjects1= [];
gdjs.Main_32SceneCode.GDGameOverTextObjects2= [];
gdjs.Main_32SceneCode.GDGameOverTextObjects3= [];
gdjs.Main_32SceneCode.GDGameOverTextObjects4= [];
gdjs.Main_32SceneCode.GDGrassTileObjects1= [];
gdjs.Main_32SceneCode.GDGrassTileObjects2= [];
gdjs.Main_32SceneCode.GDGrassTileObjects3= [];
gdjs.Main_32SceneCode.GDGrassTileObjects4= [];
gdjs.Main_32SceneCode.GDBlueGemObjects1= [];
gdjs.Main_32SceneCode.GDBlueGemObjects2= [];
gdjs.Main_32SceneCode.GDBlueGemObjects3= [];
gdjs.Main_32SceneCode.GDBlueGemObjects4= [];
gdjs.Main_32SceneCode.GDThunderBlastObjects1= [];
gdjs.Main_32SceneCode.GDThunderBlastObjects2= [];
gdjs.Main_32SceneCode.GDThunderBlastObjects3= [];
gdjs.Main_32SceneCode.GDThunderBlastObjects4= [];
gdjs.Main_32SceneCode.GDTreeObjects1= [];
gdjs.Main_32SceneCode.GDTreeObjects2= [];
gdjs.Main_32SceneCode.GDTreeObjects3= [];
gdjs.Main_32SceneCode.GDTreeObjects4= [];
gdjs.Main_32SceneCode.GDRedCrystalObjects1= [];
gdjs.Main_32SceneCode.GDRedCrystalObjects2= [];
gdjs.Main_32SceneCode.GDRedCrystalObjects3= [];
gdjs.Main_32SceneCode.GDRedCrystalObjects4= [];
gdjs.Main_32SceneCode.GDTowerWallObjects1= [];
gdjs.Main_32SceneCode.GDTowerWallObjects2= [];
gdjs.Main_32SceneCode.GDTowerWallObjects3= [];
gdjs.Main_32SceneCode.GDTowerWallObjects4= [];
gdjs.Main_32SceneCode.GDGreenKeyObjects1= [];
gdjs.Main_32SceneCode.GDGreenKeyObjects2= [];
gdjs.Main_32SceneCode.GDGreenKeyObjects3= [];
gdjs.Main_32SceneCode.GDGreenKeyObjects4= [];
gdjs.Main_32SceneCode.GDGhostObjects1= [];
gdjs.Main_32SceneCode.GDGhostObjects2= [];
gdjs.Main_32SceneCode.GDGhostObjects3= [];
gdjs.Main_32SceneCode.GDGhostObjects4= [];
gdjs.Main_32SceneCode.GDGreenDoorObjects1= [];
gdjs.Main_32SceneCode.GDGreenDoorObjects2= [];
gdjs.Main_32SceneCode.GDGreenDoorObjects3= [];
gdjs.Main_32SceneCode.GDGreenDoorObjects4= [];
gdjs.Main_32SceneCode.GDMagicShieldObjects1= [];
gdjs.Main_32SceneCode.GDMagicShieldObjects2= [];
gdjs.Main_32SceneCode.GDMagicShieldObjects3= [];
gdjs.Main_32SceneCode.GDMagicShieldObjects4= [];

gdjs.Main_32SceneCode.conditionTrue_0 = {val:false};
gdjs.Main_32SceneCode.condition0IsTrue_0 = {val:false};
gdjs.Main_32SceneCode.condition1IsTrue_0 = {val:false};
gdjs.Main_32SceneCode.condition2IsTrue_0 = {val:false};
gdjs.Main_32SceneCode.conditionTrue_1 = {val:false};
gdjs.Main_32SceneCode.condition0IsTrue_1 = {val:false};
gdjs.Main_32SceneCode.condition1IsTrue_1 = {val:false};
gdjs.Main_32SceneCode.condition2IsTrue_1 = {val:false};


gdjs.Main_32SceneCode.eventsList0 = function(runtimeScene) {

};gdjs.Main_32SceneCode.eventsList1 = function(runtimeScene) {

};gdjs.Main_32SceneCode.eventsList2 = function(runtimeScene) {

{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) > 50;
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDWizardObjects1 */
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}}

}


};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceSpellObjects3Objects = Hashtable.newFrom({"IceSpell": gdjs.Main_32SceneCode.GDIceSpellObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects = Hashtable.newFrom({"IceBlast": gdjs.Main_32SceneCode.GDIceBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects = Hashtable.newFrom({"IceBlast": gdjs.Main_32SceneCode.GDIceBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects = Hashtable.newFrom({"IceBlast": gdjs.Main_32SceneCode.GDIceBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects = Hashtable.newFrom({"ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects3});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDMagicShieldObjects3Objects = Hashtable.newFrom({"MagicShield": gdjs.Main_32SceneCode.GDMagicShieldObjects3});gdjs.Main_32SceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 1;
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) > 0;
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if ( gdjs.Main_32SceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition1IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8862956);
}
}}
if (gdjs.Main_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects2, gdjs.Main_32SceneCode.GDWizardObjects3);

gdjs.Main_32SceneCode.GDIceSpellObjects3.length = 0;

{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects3[i].setAnimationName("Attack1");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "541479__eminyildirim__magic-ice-spell-impact-punch.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(1).sub(10);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceSpellObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointX("Spell1")), (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("Spell1")), "");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDIceSpellObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceSpellObjects3[i].addForce(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) * 500, 0, 1);
}
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 2;
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) > 30;
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if ( gdjs.Main_32SceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition1IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8865452);
}
}}
if (gdjs.Main_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects2, gdjs.Main_32SceneCode.GDWizardObjects3);

gdjs.Main_32SceneCode.GDIceBlastObjects3.length = 0;

{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects3[i].setAnimationName("Attack2");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "396499__alonsotm__icespell03.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(1).sub(30);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointX("Spell2")), (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("Spell2")), "");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDIceBlastObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceBlastObjects3[i].addForce(0, -(250), 1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointX("Spell2")), (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("Spell2")), "");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDIceBlastObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceBlastObjects3[i].addForce(-(500) * gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)), 0, 0);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointX("Spell2")) - 80, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("Spell2")), "");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDIceBlastObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceBlastObjects3[i].addForce(500 * gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)), 0, 1);
}
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 3;
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= 50;
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if ( gdjs.Main_32SceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition1IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8868900);
}
}}
if (gdjs.Main_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects2, gdjs.Main_32SceneCode.GDWizardObjects3);

gdjs.Main_32SceneCode.GDThunderBlastObjects3.length = 0;

{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects3[i].setAnimationName("Attack2");
}
}{runtimeScene.getVariables().getFromIndex(1).sub(50);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) + 100, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) - 100, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) - 200, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) - 300, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) + 300, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) + 200, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getPointY("")) - 400, "");
}{gdjs.evtTools.sound.playSound(runtimeScene, "535952__doudar41__electro-hit-04.wav", false, 100, 1);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) == 0;
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects2, gdjs.Main_32SceneCode.GDWizardObjects3);

{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects3[i].setAnimationName("Idle");
}
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(6), true);
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) > 100;
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if ( gdjs.Main_32SceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition1IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8873508);
}
}}
if (gdjs.Main_32SceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects2, gdjs.Main_32SceneCode.GDWizardObjects3);

gdjs.Main_32SceneCode.GDMagicShieldObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDMagicShieldObjects3Objects, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterXInScene()) - 80 * 4, (( gdjs.Main_32SceneCode.GDWizardObjects3.length === 0 ) ? 0 :gdjs.Main_32SceneCode.GDWizardObjects3[0].getCenterYInScene()) - 80 * 4, "");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDMagicShieldObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDMagicShieldObjects3[i].setZOrder(0);
}
}{runtimeScene.getVariables().getFromIndex(1).sub(100);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDMagicShieldObjects3.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDMagicShieldObjects3[i].setScale(4);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Magic Shield.wav", false, 100, 1);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MagicShield"), gdjs.Main_32SceneCode.GDMagicShieldObjects2);
{for(var i = 0, len = gdjs.Main_32SceneCode.GDMagicShieldObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDMagicShieldObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Main_32SceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Main_32SceneCode.GDWizardObjects1, gdjs.Main_32SceneCode.GDWizardObjects2);


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDWizardObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_32SceneCode.GDWizardObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDWizardObjects2[k] = gdjs.Main_32SceneCode.GDWizardObjects2[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDWizardObjects2.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Main_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Main_32SceneCode.GDWizardObjects1 */

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDWizardObjects1.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDWizardObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDWizardObjects1[k] = gdjs.Main_32SceneCode.GDWizardObjects1[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDWizardObjects1.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDWizardObjects1 */
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].setAnimationName("Running");
}
}}

}


};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDYellowCrystalObjects1Objects = Hashtable.newFrom({"YellowCrystal": gdjs.Main_32SceneCode.GDYellowCrystalObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGreenKeyObjects1Objects = Hashtable.newFrom({"GreenKey": gdjs.Main_32SceneCode.GDGreenKeyObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGreenDoorObjects1Objects = Hashtable.newFrom({"GreenDoor": gdjs.Main_32SceneCode.GDGreenDoorObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDRedCrystalObjects1Objects = Hashtable.newFrom({"RedCrystal": gdjs.Main_32SceneCode.GDRedCrystalObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects1});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDBlueGemObjects1Objects = Hashtable.newFrom({"BlueGem": gdjs.Main_32SceneCode.GDBlueGemObjects1});gdjs.Main_32SceneCode.eventsList5 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2Objects = Hashtable.newFrom({"SkeletonPirate": gdjs.Main_32SceneCode.GDSkeletonPirateObjects2});gdjs.Main_32SceneCode.eventsList6 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGuardObjects2Objects = Hashtable.newFrom({"Guard": gdjs.Main_32SceneCode.GDGuardObjects2});gdjs.Main_32SceneCode.eventsList7 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.Main_32SceneCode.GDGhostObjects2});gdjs.Main_32SceneCode.eventsList8 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects = Hashtable.newFrom({"SkeletonPirate": gdjs.Main_32SceneCode.GDSkeletonPirateObjects2, "Guard": gdjs.Main_32SceneCode.GDGuardObjects2, "Ghost": gdjs.Main_32SceneCode.GDGhostObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceSpellObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects2Objects = Hashtable.newFrom({"IceSpell": gdjs.Main_32SceneCode.GDIceSpellObjects2, "IceBlast": gdjs.Main_32SceneCode.GDIceBlastObjects2, "ThunderBlast": gdjs.Main_32SceneCode.GDThunderBlastObjects2});gdjs.Main_32SceneCode.eventsList9 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects = Hashtable.newFrom({"SkeletonPirate": gdjs.Main_32SceneCode.GDSkeletonPirateObjects2, "Guard": gdjs.Main_32SceneCode.GDGuardObjects2, "Ghost": gdjs.Main_32SceneCode.GDGhostObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDMagicShieldObjects2Objects = Hashtable.newFrom({"MagicShield": gdjs.Main_32SceneCode.GDMagicShieldObjects2});gdjs.Main_32SceneCode.eventsList10 = function(runtimeScene) {

};gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects = Hashtable.newFrom({"SkeletonPirate": gdjs.Main_32SceneCode.GDSkeletonPirateObjects2, "Guard": gdjs.Main_32SceneCode.GDGuardObjects2, "Ghost": gdjs.Main_32SceneCode.GDGhostObjects2});gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects = Hashtable.newFrom({"Wizard": gdjs.Main_32SceneCode.GDWizardObjects2});gdjs.Main_32SceneCode.eventsList11 = function(runtimeScene) {

};gdjs.Main_32SceneCode.eventsList12 = function(runtimeScene) {

};gdjs.Main_32SceneCode.eventsList13 = function(runtimeScene) {

{


gdjs.Main_32SceneCode.eventsList0(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Main_32SceneCode.GDGameOverTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Health"), gdjs.Main_32SceneCode.GDHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Mana"), gdjs.Main_32SceneCode.GDManaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Main_32SceneCode.GDScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("WinText"), gdjs.Main_32SceneCode.GDWinTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);
{for(var i = 0, len = gdjs.Main_32SceneCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGameOverTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDWinTextObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWinTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDHealthObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDHealthObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDManaObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDManaObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDScoreObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2))));
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Main_32SceneCode.GDWizardObjects1.length !== 0 ? gdjs.Main_32SceneCode.GDWizardObjects1[0] : null), true, "", 0);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8851508);
}
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "341695__projectsu012__coins-1.wav", false, 100, 50);
}}

}


{


gdjs.Main_32SceneCode.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDWizardObjects1.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDWizardObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDWizardObjects1[k] = gdjs.Main_32SceneCode.GDWizardObjects1[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDWizardObjects1.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDWizardObjects1 */
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].setAnimationName("Jumping");
}
}
{ //Subevents
gdjs.Main_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].flipX(true);
}
}{runtimeScene.getVariables().getFromIndex(4).setNumber(-(1));
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].flipX(false);
}
}{runtimeScene.getVariables().getFromIndex(4).setNumber(1);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(1);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(2);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(3);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), true);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDWizardObjects1.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDWizardObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDWizardObjects1[k] = gdjs.Main_32SceneCode.GDWizardObjects1[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDWizardObjects1.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Main_32SceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);
gdjs.copyArray(runtimeScene.getObjects("YellowCrystal"), gdjs.Main_32SceneCode.GDYellowCrystalObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDYellowCrystalObjects1Objects, false, runtimeScene, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDYellowCrystalObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "341695__projectsu012__coins-1.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(2).add(100);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDYellowCrystalObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDYellowCrystalObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenKey"), gdjs.Main_32SceneCode.GDGreenKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGreenKeyObjects1Objects, false, runtimeScene, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDGreenKeyObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "341695__projectsu012__coins-1.wav", false, 100, 1);
}{gdjs.evtTools.common.setVariableBoolean(runtimeScene.getVariables().getFromIndex(5), true);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDGreenKeyObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGreenKeyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreenDoor"), gdjs.Main_32SceneCode.GDGreenDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGreenDoorObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableBoolean(runtimeScene.getVariables().getFromIndex(5), true);
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("WinText"), gdjs.Main_32SceneCode.GDWinTextObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Gameover");
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDWinTextObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWinTextObjects1[i].hide(false);
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedCrystal"), gdjs.Main_32SceneCode.GDRedCrystalObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition0IsTrue_0;
gdjs.Main_32SceneCode.condition0IsTrue_1.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_1.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDRedCrystalObjects1Objects, false, runtimeScene, false);
}if ( gdjs.Main_32SceneCode.condition0IsTrue_1.val ) {
{
gdjs.Main_32SceneCode.condition1IsTrue_1.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < 100;
}}
gdjs.Main_32SceneCode.conditionTrue_1.val = true && gdjs.Main_32SceneCode.condition0IsTrue_1.val && gdjs.Main_32SceneCode.condition1IsTrue_1.val;
}
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDRedCrystalObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "341695__projectsu012__coins-1.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(20);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDRedCrystalObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDRedCrystalObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueGem"), gdjs.Main_32SceneCode.GDBlueGemObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects1Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDBlueGemObjects1Objects, false, runtimeScene, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Main_32SceneCode.GDBlueGemObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "341695__projectsu012__coins-1.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(1).add(100);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDBlueGemObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDBlueGemObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);

gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDWizardObjects1.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDWizardObjects1[i].getY() >= 1000 ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDWizardObjects1[k] = gdjs.Main_32SceneCode.GDWizardObjects1[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDWizardObjects1.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Main_32SceneCode.GDGameOverTextObjects1);
/* Reuse gdjs.Main_32SceneCode.GDWizardObjects1 */
{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].setAnimationName("Falling");
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGameOverTextObjects1[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "76376__deleted-user-877451__game-over.wav", false, 20, 1);
}}

}


{


gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) <= 0;
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GameOverText"), gdjs.Main_32SceneCode.GDGameOverTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects1);
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.sound.playSound(runtimeScene, "76376__deleted-user-877451__game-over.wav", false, 20, 1);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDGameOverTextObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGameOverTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDWizardObjects1.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDWizardObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Main_32SceneCode.eventsList5(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("SkeletonPirate"), gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);

for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects2);
gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;


gdjs.Main_32SceneCode.forEachTemporary2 = gdjs.Main_32SceneCode.GDSkeletonPirateObjects1[gdjs.Main_32SceneCode.forEachIndex2];
gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.push(gdjs.Main_32SceneCode.forEachTemporary2);
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2Objects, 400, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].addForceTowardObject((gdjs.Main_32SceneCode.GDWizardObjects2.length !== 0 ? gdjs.Main_32SceneCode.GDWizardObjects2[0] : null), 200, 0);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guard"), gdjs.Main_32SceneCode.GDGuardObjects1);

for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.GDGuardObjects1.length;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects2);
gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;


gdjs.Main_32SceneCode.forEachTemporary2 = gdjs.Main_32SceneCode.GDGuardObjects1[gdjs.Main_32SceneCode.forEachIndex2];
gdjs.Main_32SceneCode.GDGuardObjects2.push(gdjs.Main_32SceneCode.forEachTemporary2);
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGuardObjects2Objects, 1000, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].addForceTowardObject((gdjs.Main_32SceneCode.GDWizardObjects2.length !== 0 ? gdjs.Main_32SceneCode.GDWizardObjects2[0] : null), 100, 0);
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].setAnimationName("Run");
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.Main_32SceneCode.GDGhostObjects1);

for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.GDGhostObjects1.length;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects2);
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;


gdjs.Main_32SceneCode.forEachTemporary2 = gdjs.Main_32SceneCode.GDGhostObjects1[gdjs.Main_32SceneCode.forEachIndex2];
gdjs.Main_32SceneCode.GDGhostObjects2.push(gdjs.Main_32SceneCode.forEachTemporary2);
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects, 1500, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].addForceTowardObject((gdjs.Main_32SceneCode.GDWizardObjects2.length !== 0 ? gdjs.Main_32SceneCode.GDWizardObjects2[0] : null), 300, 0);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.Main_32SceneCode.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Guard"), gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SkeletonPirate"), gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);

gdjs.Main_32SceneCode.forEachTotalCount2 = 0;
gdjs.Main_32SceneCode.forEachObjects2.length = 0;
gdjs.Main_32SceneCode.forEachCount0_2 = gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount0_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);
gdjs.Main_32SceneCode.forEachCount1_2 = gdjs.Main_32SceneCode.GDGuardObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount1_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.Main_32SceneCode.forEachCount2_2 = gdjs.Main_32SceneCode.GDGhostObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount2_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGhostObjects1);
for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachTotalCount2;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("IceBlast"), gdjs.Main_32SceneCode.GDIceBlastObjects2);
gdjs.copyArray(runtimeScene.getObjects("IceSpell"), gdjs.Main_32SceneCode.GDIceSpellObjects2);
gdjs.copyArray(runtimeScene.getObjects("ThunderBlast"), gdjs.Main_32SceneCode.GDThunderBlastObjects2);
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;

gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;

gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;


if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2) {
    gdjs.Main_32SceneCode.GDGuardObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2+gdjs.Main_32SceneCode.forEachCount2_2) {
    gdjs.Main_32SceneCode.GDGhostObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDIceSpellObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDIceBlastObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDThunderBlastObjects2Objects, false, runtimeScene, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDThunderBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceSpellObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDIceSpellObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDIceBlastObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDThunderBlastObjects2[0].getVariables()).get("Strength"))));
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDGuardObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDThunderBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceSpellObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDIceSpellObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDIceBlastObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDThunderBlastObjects2[0].getVariables()).get("Strength"))));
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDGhostObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDThunderBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceBlastObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDIceSpellObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDIceSpellObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDIceBlastObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDThunderBlastObjects2[0].getVariables()).get("Strength"))));
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDIceSpellObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceSpellObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDIceBlastObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDIceBlastObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDThunderBlastObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDThunderBlastObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(2).add(10);
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].getBehavior("Flash").Flash(5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].getBehavior("Flash").Flash(5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].setColor("250;161;161");
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].setColor("250;161;161");
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].setColor("250;161;161");
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.Main_32SceneCode.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Guard"), gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SkeletonPirate"), gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);

gdjs.Main_32SceneCode.forEachTotalCount2 = 0;
gdjs.Main_32SceneCode.forEachObjects2.length = 0;
gdjs.Main_32SceneCode.forEachCount0_2 = gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount0_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);
gdjs.Main_32SceneCode.forEachCount1_2 = gdjs.Main_32SceneCode.GDGuardObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount1_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.Main_32SceneCode.forEachCount2_2 = gdjs.Main_32SceneCode.GDGhostObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount2_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGhostObjects1);
for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachTotalCount2;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("MagicShield"), gdjs.Main_32SceneCode.GDMagicShieldObjects2);
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;

gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;

gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;


if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2) {
    gdjs.Main_32SceneCode.GDGuardObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2+gdjs.Main_32SceneCode.forEachCount2_2) {
    gdjs.Main_32SceneCode.GDGhostObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDMagicShieldObjects2Objects, false, runtimeScene, false);
}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].setColor("119;152;230");
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].setColor("119;152;230");
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].setColor("119;152;230");
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDMagicShieldObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDMagicShieldObjects2[0].getVariables()).getFromIndex(0))));
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDGuardObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDMagicShieldObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDMagicShieldObjects2[0].getVariables()).getFromIndex(0))));
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].returnVariable(gdjs.Main_32SceneCode.GDGhostObjects2[i].getVariables().get("HP")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDMagicShieldObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDMagicShieldObjects2[0].getVariables()).getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].addForce(3000, 3000, 0);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].addForce(3000, 3000, 0);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].addForce(3000, 3000, 0);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.Main_32SceneCode.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Guard"), gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SkeletonPirate"), gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);

gdjs.Main_32SceneCode.forEachTotalCount2 = 0;
gdjs.Main_32SceneCode.forEachObjects2.length = 0;
gdjs.Main_32SceneCode.forEachCount0_2 = gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount0_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);
gdjs.Main_32SceneCode.forEachCount1_2 = gdjs.Main_32SceneCode.GDGuardObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount1_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.Main_32SceneCode.forEachCount2_2 = gdjs.Main_32SceneCode.GDGhostObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount2_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGhostObjects1);
for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachTotalCount2;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Wizard"), gdjs.Main_32SceneCode.GDWizardObjects2);
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;

gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;

gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;


if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2) {
    gdjs.Main_32SceneCode.GDGuardObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2+gdjs.Main_32SceneCode.forEachCount2_2) {
    gdjs.Main_32SceneCode.GDGhostObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
gdjs.Main_32SceneCode.condition1IsTrue_0.val = false;
{
gdjs.Main_32SceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDSkeletonPirateObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGuardObjects2ObjectsGDgdjs_46Main_9532SceneCode_46GDGhostObjects2Objects, gdjs.Main_32SceneCode.mapOfGDgdjs_46Main_9532SceneCode_46GDWizardObjects2Objects, false, runtimeScene, false);
}if ( gdjs.Main_32SceneCode.condition0IsTrue_0.val ) {
{
{gdjs.Main_32SceneCode.conditionTrue_1 = gdjs.Main_32SceneCode.condition1IsTrue_0;
gdjs.Main_32SceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8891084);
}
}}
if (gdjs.Main_32SceneCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.Main_32SceneCode.GDGhostObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDGuardObjects2.length === 0 ) ? ((gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDGuardObjects2[0].getVariables()) : gdjs.Main_32SceneCode.GDGhostObjects2[0].getVariables()).get("Attackpower"))));
}{gdjs.evtTools.sound.playSound(runtimeScene, "404747__owlstorm__retro-video-game-sfx-ouch.wav", false, 100, 1);
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.Main_32SceneCode.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Guard"), gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SkeletonPirate"), gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);

gdjs.Main_32SceneCode.forEachTotalCount2 = 0;
gdjs.Main_32SceneCode.forEachObjects2.length = 0;
gdjs.Main_32SceneCode.forEachCount0_2 = gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount0_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDSkeletonPirateObjects1);
gdjs.Main_32SceneCode.forEachCount1_2 = gdjs.Main_32SceneCode.GDGuardObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount1_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGuardObjects1);
gdjs.Main_32SceneCode.forEachCount2_2 = gdjs.Main_32SceneCode.GDGhostObjects1.length;
gdjs.Main_32SceneCode.forEachTotalCount2 += gdjs.Main_32SceneCode.forEachCount2_2;
gdjs.Main_32SceneCode.forEachObjects2.push.apply(gdjs.Main_32SceneCode.forEachObjects2,gdjs.Main_32SceneCode.GDGhostObjects1);
for(gdjs.Main_32SceneCode.forEachIndex2 = 0;gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachTotalCount2;++gdjs.Main_32SceneCode.forEachIndex2) {
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;

gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;

gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;


if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2) {
    gdjs.Main_32SceneCode.GDGuardObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
else if (gdjs.Main_32SceneCode.forEachIndex2 < gdjs.Main_32SceneCode.forEachCount0_2+gdjs.Main_32SceneCode.forEachCount1_2+gdjs.Main_32SceneCode.forEachCount2_2) {
    gdjs.Main_32SceneCode.GDGhostObjects2.push(gdjs.Main_32SceneCode.forEachObjects2[gdjs.Main_32SceneCode.forEachIndex2]);
}
gdjs.Main_32SceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].getVariableNumber(gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].getVariables().get("HP")) <= 0 ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[k] = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDGuardObjects2.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDGuardObjects2[i].getVariableNumber(gdjs.Main_32SceneCode.GDGuardObjects2[i].getVariables().get("HP")) <= 0 ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDGuardObjects2[k] = gdjs.Main_32SceneCode.GDGuardObjects2[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDGuardObjects2.length = k;for(var i = 0, k = 0, l = gdjs.Main_32SceneCode.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.Main_32SceneCode.GDGhostObjects2[i].getVariableNumber(gdjs.Main_32SceneCode.GDGhostObjects2[i].getVariables().get("HP")) <= 0 ) {
        gdjs.Main_32SceneCode.condition0IsTrue_0.val = true;
        gdjs.Main_32SceneCode.GDGhostObjects2[k] = gdjs.Main_32SceneCode.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.Main_32SceneCode.GDGhostObjects2.length = k;}if (gdjs.Main_32SceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDSkeletonPirateObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGuardObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGuardObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Main_32SceneCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.Main_32SceneCode.GDGhostObjects2[i].deleteFromScene(runtimeScene);
}
}}
}

}


};

gdjs.Main_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32SceneCode.GDWizardObjects1.length = 0;
gdjs.Main_32SceneCode.GDWizardObjects2.length = 0;
gdjs.Main_32SceneCode.GDWizardObjects3.length = 0;
gdjs.Main_32SceneCode.GDWizardObjects4.length = 0;
gdjs.Main_32SceneCode.GDBlueFloorObjects1.length = 0;
gdjs.Main_32SceneCode.GDBlueFloorObjects2.length = 0;
gdjs.Main_32SceneCode.GDBlueFloorObjects3.length = 0;
gdjs.Main_32SceneCode.GDBlueFloorObjects4.length = 0;
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects1.length = 0;
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects2.length = 0;
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects3.length = 0;
gdjs.Main_32SceneCode.GDIndustrialPlatformCenterObjects4.length = 0;
gdjs.Main_32SceneCode.GDHealthObjects1.length = 0;
gdjs.Main_32SceneCode.GDHealthObjects2.length = 0;
gdjs.Main_32SceneCode.GDHealthObjects3.length = 0;
gdjs.Main_32SceneCode.GDHealthObjects4.length = 0;
gdjs.Main_32SceneCode.GDManaObjects1.length = 0;
gdjs.Main_32SceneCode.GDManaObjects2.length = 0;
gdjs.Main_32SceneCode.GDManaObjects3.length = 0;
gdjs.Main_32SceneCode.GDManaObjects4.length = 0;
gdjs.Main_32SceneCode.GDScoreObjects1.length = 0;
gdjs.Main_32SceneCode.GDScoreObjects2.length = 0;
gdjs.Main_32SceneCode.GDScoreObjects3.length = 0;
gdjs.Main_32SceneCode.GDScoreObjects4.length = 0;
gdjs.Main_32SceneCode.GDYellowCrystalObjects1.length = 0;
gdjs.Main_32SceneCode.GDYellowCrystalObjects2.length = 0;
gdjs.Main_32SceneCode.GDYellowCrystalObjects3.length = 0;
gdjs.Main_32SceneCode.GDYellowCrystalObjects4.length = 0;
gdjs.Main_32SceneCode.GDSkeletonPirateObjects1.length = 0;
gdjs.Main_32SceneCode.GDSkeletonPirateObjects2.length = 0;
gdjs.Main_32SceneCode.GDSkeletonPirateObjects3.length = 0;
gdjs.Main_32SceneCode.GDSkeletonPirateObjects4.length = 0;
gdjs.Main_32SceneCode.GDRedPlatformObjects1.length = 0;
gdjs.Main_32SceneCode.GDRedPlatformObjects2.length = 0;
gdjs.Main_32SceneCode.GDRedPlatformObjects3.length = 0;
gdjs.Main_32SceneCode.GDRedPlatformObjects4.length = 0;
gdjs.Main_32SceneCode.GDBrownBlockObjects1.length = 0;
gdjs.Main_32SceneCode.GDBrownBlockObjects2.length = 0;
gdjs.Main_32SceneCode.GDBrownBlockObjects3.length = 0;
gdjs.Main_32SceneCode.GDBrownBlockObjects4.length = 0;
gdjs.Main_32SceneCode.GDIceSpellObjects1.length = 0;
gdjs.Main_32SceneCode.GDIceSpellObjects2.length = 0;
gdjs.Main_32SceneCode.GDIceSpellObjects3.length = 0;
gdjs.Main_32SceneCode.GDIceSpellObjects4.length = 0;
gdjs.Main_32SceneCode.GDIceBlastObjects1.length = 0;
gdjs.Main_32SceneCode.GDIceBlastObjects2.length = 0;
gdjs.Main_32SceneCode.GDIceBlastObjects3.length = 0;
gdjs.Main_32SceneCode.GDIceBlastObjects4.length = 0;
gdjs.Main_32SceneCode.GDLargeGuardObjects1.length = 0;
gdjs.Main_32SceneCode.GDLargeGuardObjects2.length = 0;
gdjs.Main_32SceneCode.GDLargeGuardObjects3.length = 0;
gdjs.Main_32SceneCode.GDLargeGuardObjects4.length = 0;
gdjs.Main_32SceneCode.GDGuardObjects1.length = 0;
gdjs.Main_32SceneCode.GDGuardObjects2.length = 0;
gdjs.Main_32SceneCode.GDGuardObjects3.length = 0;
gdjs.Main_32SceneCode.GDGuardObjects4.length = 0;
gdjs.Main_32SceneCode.GDWinTextObjects1.length = 0;
gdjs.Main_32SceneCode.GDWinTextObjects2.length = 0;
gdjs.Main_32SceneCode.GDWinTextObjects3.length = 0;
gdjs.Main_32SceneCode.GDWinTextObjects4.length = 0;
gdjs.Main_32SceneCode.GDGameOverTextObjects1.length = 0;
gdjs.Main_32SceneCode.GDGameOverTextObjects2.length = 0;
gdjs.Main_32SceneCode.GDGameOverTextObjects3.length = 0;
gdjs.Main_32SceneCode.GDGameOverTextObjects4.length = 0;
gdjs.Main_32SceneCode.GDGrassTileObjects1.length = 0;
gdjs.Main_32SceneCode.GDGrassTileObjects2.length = 0;
gdjs.Main_32SceneCode.GDGrassTileObjects3.length = 0;
gdjs.Main_32SceneCode.GDGrassTileObjects4.length = 0;
gdjs.Main_32SceneCode.GDBlueGemObjects1.length = 0;
gdjs.Main_32SceneCode.GDBlueGemObjects2.length = 0;
gdjs.Main_32SceneCode.GDBlueGemObjects3.length = 0;
gdjs.Main_32SceneCode.GDBlueGemObjects4.length = 0;
gdjs.Main_32SceneCode.GDThunderBlastObjects1.length = 0;
gdjs.Main_32SceneCode.GDThunderBlastObjects2.length = 0;
gdjs.Main_32SceneCode.GDThunderBlastObjects3.length = 0;
gdjs.Main_32SceneCode.GDThunderBlastObjects4.length = 0;
gdjs.Main_32SceneCode.GDTreeObjects1.length = 0;
gdjs.Main_32SceneCode.GDTreeObjects2.length = 0;
gdjs.Main_32SceneCode.GDTreeObjects3.length = 0;
gdjs.Main_32SceneCode.GDTreeObjects4.length = 0;
gdjs.Main_32SceneCode.GDRedCrystalObjects1.length = 0;
gdjs.Main_32SceneCode.GDRedCrystalObjects2.length = 0;
gdjs.Main_32SceneCode.GDRedCrystalObjects3.length = 0;
gdjs.Main_32SceneCode.GDRedCrystalObjects4.length = 0;
gdjs.Main_32SceneCode.GDTowerWallObjects1.length = 0;
gdjs.Main_32SceneCode.GDTowerWallObjects2.length = 0;
gdjs.Main_32SceneCode.GDTowerWallObjects3.length = 0;
gdjs.Main_32SceneCode.GDTowerWallObjects4.length = 0;
gdjs.Main_32SceneCode.GDGreenKeyObjects1.length = 0;
gdjs.Main_32SceneCode.GDGreenKeyObjects2.length = 0;
gdjs.Main_32SceneCode.GDGreenKeyObjects3.length = 0;
gdjs.Main_32SceneCode.GDGreenKeyObjects4.length = 0;
gdjs.Main_32SceneCode.GDGhostObjects1.length = 0;
gdjs.Main_32SceneCode.GDGhostObjects2.length = 0;
gdjs.Main_32SceneCode.GDGhostObjects3.length = 0;
gdjs.Main_32SceneCode.GDGhostObjects4.length = 0;
gdjs.Main_32SceneCode.GDGreenDoorObjects1.length = 0;
gdjs.Main_32SceneCode.GDGreenDoorObjects2.length = 0;
gdjs.Main_32SceneCode.GDGreenDoorObjects3.length = 0;
gdjs.Main_32SceneCode.GDGreenDoorObjects4.length = 0;
gdjs.Main_32SceneCode.GDMagicShieldObjects1.length = 0;
gdjs.Main_32SceneCode.GDMagicShieldObjects2.length = 0;
gdjs.Main_32SceneCode.GDMagicShieldObjects3.length = 0;
gdjs.Main_32SceneCode.GDMagicShieldObjects4.length = 0;

gdjs.Main_32SceneCode.eventsList13(runtimeScene);
return;

}

gdjs['Main_32SceneCode'] = gdjs.Main_32SceneCode;
